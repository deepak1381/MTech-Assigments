package allJavaClasses;

import java.util.Random;

public class ProcessorRegisters {

	private static int regA = 0;
	private static int regB = 0;
	private static int regC = 0;
	private static int regD = 0;
	private static int regH = 0;
	private static int regL = 0;
	private static int regSP = 0;
	private static int regPC = 0;
	private static int regDummy1 = 100;

	public static int programCounter = 0;
	private String[] memoryLocation = { "0x0000", "0x0008", "0x0010", "0x0018", "0x0020", "0x0028", "0x0030",
			"0x0038" };
	public static int memory[][] = new int[10][8];

	public static int getProgramCounter() {
		return programCounter;
	}

	public static void setProgramCounter(int programCounter) {
		ProcessorRegisters.programCounter = programCounter;
	}

	// public static String []=new String[8];

	// generate any random numnber to be stored in memory location
	public static void generateRandomNumber() {

		Random rand = new Random();
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				int n = rand.nextInt(5);
				memory[i][j] = n;
			}
		}
	}

	public String[] getMemoryLocation() {
		return memoryLocation;
	}

	public void setMemoryLocation(String[] memoryLocation) {
		this.memoryLocation = memoryLocation;
	}

	public static void setMemory(int[][] memory) {
		ProcessorRegisters.memory = memory;
	}

	public static int[][] getMemory() {
		return memory;
	}

	public static int getRegDummy1() {
		return regDummy1;
	}

	public static void setRegDummy1(int regDummy) {
		ProcessorRegisters.regDummy1 = regDummy;
	}

	public static int getRegSP() {
		return regSP;
	}

	public static void setRegSP(int regSP) {
		ProcessorRegisters.regSP = regSP;
	}

	public static int getRegPC() {
		return regPC;
	}

	public static void setRegPC(int regPC) {
		ProcessorRegisters.regPC = regPC;
	}

	public static int getRegH() {
		return regH;
	}

	public static void setRegH(int regH) {
		ProcessorRegisters.regH = regH;
	}

	public static int getRegL() {
		return regL;
	}

	public static void setRegL(int regL) {
		ProcessorRegisters.regL = regL;
	}

	public static int getRegA() {
		return regA;
	}

	public static void setRegA(int regA) {
		ProcessorRegisters.regA = regA;
	}

	public static int getRegB() {
		return regB;
	}

	public static void setRegB(int regB) {
		ProcessorRegisters.regB = regB;
	}

	public static int getRegC() {
		return regC;
	}

	public static void setRegC(int regC) {
		ProcessorRegisters.regC = regC;
	}

	public static int getRegD() {
		return regD;
	}

	public static void setRegD(int regD) {
		ProcessorRegisters.regD = regD;
	}

	///////////////////////////////////////////////////////////////////////////////////////

	public void ADD(String op1, String op2) {

		// System.out.println("inside ADD " + regA);

		String[] op1Split = op1.split(",");

		String[] op2Split = op2.split("H");

		if (op2.equals("A") | op2.equals("B") | op2.equals("C") | op2.equals("D")) {

			if (op1Split[0].equals("A")) {

				if (op2Split[0].equals("B")) {
					regA = regA + regB;
				} else if (op2Split[0].equals("C")) {
					regA = regA + regC;
				} else if (op2Split[0].equals("D")) {
					regA = regA + regD;
				}
			} else if (op1Split[0].equals("B")) {

				if (op2Split[0].equals("A")) {
					regB = regB + regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("C")) {
					regB = regB + regC;
				} else if (op2Split[0].equals("D")) {
					regB = regB + regD;
				}
			}

			else if (op1Split[0].equals("C")) {

				if (op2Split[0].equals("A")) {
					regC -= regC + regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regC = regC + regB;
				} else if (op2Split[0].equals("D")) {
					regC = regC + regD;
				}
			}

			else if (op1Split[0].equals("D")) {

				if (op2Split[0].equals("A")) {
					regD = regD + regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regD = regD + regB;
				} else if (op2Split[0].equals("C")) {
					regD = regD + regC;
				}
			}
		}
	}

	public void MUL(String op1, String op2) {

		String[] op1Split = op1.split(",");

		String[] op2Split = op2.split("H");

		if (op2.equals("A") | op2.equals("B") | op2.equals("C") | op2.equals("D")) {

			if (op1Split[0].equals("A")) {

				if (op2Split[0].equals("B")) {
					regA = regA * regB;
				} else if (op2Split[0].equals("C")) {
					regA = regA * regC;
				} else if (op2Split[0].equals("D")) {
					regA = regA * regD;
				}
			} else if (op1Split[0].equals("B")) {

				if (op2Split[0].equals("A")) {
					regB = regB * regA;

				} else if (op2Split[0].equals("C")) {
					regB = regB * regC;
				} else if (op2Split[0].equals("D")) {
					regB = regB * regD;
				}
			}

			else if (op1Split[0].equals("C")) {

				if (op2Split[0].equals("A")) {
					regC -= regC * regA;

				} else if (op2Split[0].equals("B")) {
					regC = regC * regB;
				} else if (op2Split[0].equals("D")) {
					regC = regC * regD;
				}
			}

			else if (op1Split[0].equals("D")) {

				if (op2Split[0].equals("A")) {
					regD = regD * regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regD = regD * regB;
				} else if (op2Split[0].equals("C")) {
					regD = regD * regC;
				}
			}
		}
	}

	public void SUB(String op1, String op2) {

		String[] op1Split = op1.split(",");

		String[] op2Split = op2.split("H");

		if (op2.equals("A") | op2.equals("B") | op2.equals("C") | op2.equals("D")) {

			if (op1Split[0].equals("A")) {

				if (op2Split[0].equals("B")) {
					regA = regA - regB;
				} else if (op2Split[0].equals("C")) {
					regA = regA - regC;
				} else if (op2Split[0].equals("D")) {
					regA = regA - regD;
				}
			} else if (op1Split[0].equals("B")) {

				if (op2Split[0].equals("A")) {
					regB = regB - regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("C")) {
					regB = regB - regC;
				} else if (op2Split[0].equals("D")) {
					regB = regB - regD;
				}
			}

			else if (op1Split[0].equals("C")) {

				if (op2Split[0].equals("A")) {
					regC -= regC - regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regC = regC - regB;
				} else if (op2Split[0].equals("D")) {
					regC = regC - regD;
				}
			}

			else if (op1Split[0].equals("D")) {

				if (op2Split[0].equals("A")) {
					regD = regD - regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regD = regD - regB;
				} else if (op2Split[0].equals("C")) {
					regD = regD - regC;
				}
			}
		}
	}

	public void MVI(String op1, String op2) {

		String[] op1Split = op1.split(","); // separate ,
		String[] op2Split = op2.split("H"); // separate h
		String[] op2Split2 = op2Split[0].split("#"); // separate #

		if (op1Split[0].equals("A")) {

			regA = Integer.parseInt(op2Split2[1]);
		}

		if (op1Split[0].equals("B")) {

			regB = Integer.parseInt(op2Split2[1]);

			// System.out.println("inside regB " + regB);
		}

		if (op1Split[0].equals("C")) {

			regC = Integer.parseInt(op2Split2[1]);
		}

		if (op1Split[0].equals("D")) {

			regD = Integer.parseInt(op2Split2[1]);
		}

		if (op1Split[0].equals("H")) {

			regH = Integer.parseInt(op2Split2[1]);
		}

	}

	public void MOV(String op1, String op2) {

		String[] op1Split = op1.split(","); // separate ,
		String[] op2Split = op2.split("H"); // separate h
		// find the addressing mode//

		char first = op2.charAt(0);

		// immediate addressing
		// mode//////////////////////////////////////////////////////////////////////////////

		if (first == '#') {
			// System.out.print("#################");

			String[] op2Split2 = op2Split[0].split("#"); // separate #

			if (op1Split[0].equals("A")) {

				regA = Integer.parseInt(op2Split2[1]);
			}

			else if (op1Split[0].equals("B")) {

				regB = Integer.parseInt(op2Split2[1]);

				// System.out.println("inside regB " + regB);
			}

			else if (op1Split[0].equals("C")) {

				regC = Integer.parseInt(op2Split2[1]);
			}

			else if (op1Split[0].equals("D")) {

				regD = Integer.parseInt(op2Split2[1]);
			}

			else if (op1Split[0].equals("H")) {

				regH = Integer.parseInt(op2Split2[1]);
			}

		}

		/* Register addresing mode */

		else if (first == 'A' | first == 'B' | first == 'C' | first == 'D' | first == 'A') {

			if (op1Split[0].equals("A")) {

				if (op2Split[0].equals("B")) {
					regA = regB;
				} else if (op2Split[0].equals("C")) {
					regA = regC;
				} else if (op2Split[0].equals("D")) {
					regA = regD;
				}
			} else if (op1Split[0].equals("B")) {

				if (op2Split[0].equals("A")) {
					regB = regA;

					System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("C")) {
					regB = regC;
				} else if (op2Split[0].equals("D")) {
					regB = regD;
				}
			}

			else if (op1Split[0].equals("C")) {

				if (op2Split[0].equals("A")) {
					regC = regA;

					System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regC = regB;
				} else if (op2Split[0].equals("D")) {
					regC = regD;
				}
			}

			else if (op1Split[0].equals("D")) {

				if (op2Split[0].equals("A")) {
					regD = regA;

					System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regD = regB;
				} else if (op2Split[0].equals("C")) {
					regD = regC;
				}
			}
		}
		/* Direct Addressing mode */

		else {

			int row, column;
			row = Integer.parseInt(op2Split[0]) / 8;
			column = Integer.parseInt(op2Split[0]) % 8;

			// System.out.println("Row " + row);
			// System.out.println("Column " + column);
			int memoryLocationData = memory[row][column - 1];
			// System.out.println("mem data " + memoryLocationData);

			if (op1Split[0].equals("A")) {

				regA = memoryLocationData;
			}

			if (op1Split[0].equals("B")) {

				regB = memoryLocationData;

				// System.out.println("inside regB " + regB);
			}

			if (op1Split[0].equals("C")) {

				regC = memoryLocationData;
			}

			if (op1Split[0].equals("D")) {

				regD = memoryLocationData;
			}

			if (op1Split[0].equals("H")) {

				regH = memoryLocationData;
			}
		}
	}

	public void INC(String op1) {

		String[] op1Split = op1.split(","); // separate ,
		// String [] op2Split= op2.split("H"); //separate h
		// String [] op2Split2= op2Split[0].split("#"); //separate #

		if (op1Split[0].equals("A")) {

			regA = regA + 1;
		}

		if (op1Split[0].equals("B")) {

			regB = regB + 1;

			// System.out.println("inside regB " + regB);
		}

		if (op1Split[0].equals("C")) {

			regC = regC + 1;
		}

		if (op1Split[0].equals("D")) {

			regD = regD + 1;
		}

		if (op1Split[0].equals("H")) {

			regH = regH + 1;
		}

	}

	public void DEC(String op1) {

		String[] op1Split = op1.split(","); // separate ,
		// String [] op2Split= op2.split("H"); //separate h
		// String [] op2Split2= op2Split[0].split("#"); //separate #

		if (op1Split[0].equals("A")) {

			regA = regA - 1;
		}

		if (op1Split[0].equals("B")) {

			regB = regB - 1;

			// System.out.println("inside regB " + regB);
		}

		if (op1Split[0].equals("C")) {

			regC = regC - 1;
		}

		if (op1Split[0].equals("D")) {

			regD = regD - 1;
		}

		if (op1Split[0].equals("H")) {

			regH = regH - 1;
		}

	}

	public void ANL(String op1, String op2) {

		// System.out.println("inside ADD " + regA);

		String[] op1Split = op1.split(",");

		String[] op2Split = op2.split("H");

		if (op2.equals("A") | op2.equals("B") | op2.equals("C") | op2.equals("D")) {

			if (op1Split[0].equals("A")) {

				if (op2Split[0].equals("B")) {
					regA = regA & regB;
				} else if (op2Split[0].equals("C")) {
					regA = regA & regC;
				} else if (op2Split[0].equals("D")) {
					regA = regA & regD;
				}
			} else if (op1Split[0].equals("B")) {

				if (op2Split[0].equals("A")) {
					regB = regB & regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("C")) {
					regB = regB & regC;
				} else if (op2Split[0].equals("D")) {
					regB = regB & regD;
				}
			}

			else if (op1Split[0].equals("C")) {

				if (op2Split[0].equals("A")) {
					regC -= regC & regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regC = regC & regB;
				} else if (op2Split[0].equals("D")) {
					regC = regC & regD;
				}
			}

			else if (op1Split[0].equals("D")) {

				if (op2Split[0].equals("A")) {
					regD = regD & regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regD = regD & regB;
				} else if (op2Split[0].equals("C")) {
					regD = regD & regC;
				}
			}
		}
	}

	public void XRL(String op1, String op2) {

		// System.out.println("inside ADD " + regA);

		String[] op1Split = op1.split(",");

		String[] op2Split = op2.split("H");

		if (op2.equals("A") | op2.equals("B") | op2.equals("C") | op2.equals("D")) {

			if (op1Split[0].equals("A")) {

				if (op2Split[0].equals("B")) {
					regA = regA ^ regB;
				} else if (op2Split[0].equals("C")) {
					regA = regA ^ regC;
				} else if (op2Split[0].equals("D")) {
					regA = regA ^ regD;
				}
			} else if (op1Split[0].equals("B")) {

				if (op2Split[0].equals("A")) {
					regB = regB ^ regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("C")) {
					regB = regB ^ regC;
				} else if (op2Split[0].equals("D")) {
					regB = regB ^ regD;
				}
			}

			else if (op1Split[0].equals("C")) {

				if (op2Split[0].equals("A")) {
					regC -= regC ^ regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regC = regC ^ regB;
				} else if (op2Split[0].equals("D")) {
					regC = regC ^ regD;
				}
			}

			else if (op1Split[0].equals("D")) {

				if (op2Split[0].equals("A")) {
					regD = regD ^ regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regD = regD ^ regB;
				} else if (op2Split[0].equals("C")) {
					regD = regD ^ regC;
				}
			}
		}
	}

	public void ORL(String op1, String op2) {

		// System.out.println("inside ADD " + regA);

		String[] op1Split = op1.split(",");

		String[] op2Split = op2.split("H");

		if (op2.equals("A") | op2.equals("B") | op2.equals("C") | op2.equals("D")) {

			if (op1Split[0].equals("A")) {

				if (op2Split[0].equals("B")) {
					regA = regA | regB;
				} else if (op2Split[0].equals("C")) {
					regA = regA | regC;
				} else if (op2Split[0].equals("D")) {
					regA = regA | regD;
				}
			} else if (op1Split[0].equals("B")) {

				if (op2Split[0].equals("A")) {
					regB = regB | regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("C")) {
					regB = regB | regC;
				} else if (op2Split[0].equals("D")) {
					regB = regB | regD;
				}
			}

			else if (op1Split[0].equals("C")) {

				if (op2Split[0].equals("A")) {
					regC -= regC | regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regC = regC | regB;
				} else if (op2Split[0].equals("D")) {
					regC = regC | regD;
				}
			}

			else if (op1Split[0].equals("D")) {

				if (op2Split[0].equals("A")) {
					regD = regD | regA;

					// System.out.println("inside B " + regB);
				} else if (op2Split[0].equals("B")) {
					regD = regD | regB;
				} else if (op2Split[0].equals("C")) {
					regD = regD | regC;
				}
			}
		}
	}

	public static String decTobinary(int n) {

		// array to store binary number
		int[] binaryNum = new int[1000];
		String bin = "";

		// counter for binary array
		int i = 0;
		while (n > 0) {
			// storing remainder in binary array
			binaryNum[i] = n % 2;
			n = n / 2;
			i++;
		}

		// printing binary array in reverse order
		for (int j = i - 1; j >= 0; j--) {
			
			bin = bin + binaryNum[j];
		}
		
		
		return bin;

	}

	public static String decToHex(int n) {

		String hex = Integer.toHexString(n);
		return hex;

	}
}
