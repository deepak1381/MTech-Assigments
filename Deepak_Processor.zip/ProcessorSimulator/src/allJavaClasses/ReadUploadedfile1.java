package allJavaClasses;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

public class ReadUploadedfile1 extends HttpServlet { 
  protected void doGet(HttpServletRequest request, 
      HttpServletResponse response) throws ServletException, IOException 
  {
    // reading the user input
      
   
    ReadUploadedFile rf = new ReadUploadedFile();
    
    if((ReadUploadedFile.storedCommands.size())-2>=ProcessorRegisters.programCounter) {
		    
		   rf.fetchCommandsLineByLine();
		   RequestDispatcher rd=request.getRequestDispatcher("Execute.jsp");
		   rd.forward(request, response);
		   
	  
	   }
    
    else {
    
    	rf.fetchCommandsLineByLine();
		RequestDispatcher rd = request.getRequestDispatcher("Final.jsp");
		rd.forward(request, response);
		}
    
    
    
}
}