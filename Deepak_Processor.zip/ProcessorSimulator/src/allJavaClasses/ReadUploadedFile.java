package allJavaClasses;

import java.io.*;
//import java.util.List;
import java.util.Scanner;
import java.util.*;

public class ReadUploadedFile {

	private String fileLocation = null;
	public static ArrayList<String> storedCommands = new ArrayList<String>();

	public ArrayList<String> getStoredCommands() {
		return storedCommands;
	}

	public void setStoredCommands(ArrayList<String> storedCommands) {
		this.storedCommands = storedCommands;
	}

	public String getPath() {

		return fileLocation;

	}

	public void setPath(String uploadedFileLocation) {

		fileLocation = uploadedFileLocation;

	}

	public void printUploadedFile() throws IOException {

		ProcessorRegisters.generateRandomNumber(); // initializing memory with random values
		ProcessorRegisters.programCounter = 0;

		try {
			File file = new File(fileLocation);
			Scanner sc = new Scanner(file);
			ArrayList<String> ar = new ArrayList<String>(); ///
			while (sc.hasNextLine()) {

				String line = sc.nextLine();

				ar.add(line);
				storedCommands = ar;
			}

			//for (String s : storedCommands) {
				//System.out.println(s);

			//}
			sc.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
		//System.out.println(storedCommands);
	}

	/////////////////// deviding in half to store command/////
	///////////////// to execute command //

	public void fetchCommandsLineByLine() {

		String[] split1 = storedCommands.get(ProcessorRegisters.getProgramCounter()).split(" ");

		if (split1[0].equals("MVI")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.MVI(split1[1], split1[2]);

		}

		else if (split1[0].equals("ADD")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.ADD(split1[1], split1[2]);

		}

		else if (split1[0].equals("MOV")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.MOV(split1[1], split1[2]);
		}

		else if (split1[0].equals("ADD")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.ADD(split1[1], split1[2]);
		}

		else if (split1[0].equals("SUB")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.SUB(split1[1], split1[2]);
		}

		else if (split1[0].equals("MUL")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.MUL(split1[1], split1[2]);
		}

		else if (split1[0].equals("INC")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.INC(split1[1]);
		}

		else if (split1[0].equals("DEC")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.DEC(split1[1]);

		}

		else if (split1[0].equals("ANL")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.ANL(split1[1], split1[2]);
		}

		else if (split1[0].equals("ORL")) {

			ProcessorRegisters pr = new ProcessorRegisters();
			pr.ORL(split1[1], split1[2]);
		}

		else if (split1[0].equals("XRL")) {
			ProcessorRegisters pr = new ProcessorRegisters();
			pr.XRL(split1[1], split1[2]);
		}

		if ((storedCommands.size()) > ProcessorRegisters.programCounter) {

			ProcessorRegisters.programCounter++;

		}
	}

}
